import { Component } from '@angular/core';
import { BankAccountDetails } from './bank-account-details';
import { TransactionType, BankTransaction } from './bank-transaction'
import { UserCredentials } from './user-credentials';
import * as CryptoJS from 'crypto-js';

const SALT: string = "AM2468עמ$$";
const USER_CREDENTIALS_KY: string = "USER_CREDENTIALS";
const TRANSACTIONS_STORAGE_KEY: string = "BANK_TRANSACTIONS";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  transaction?: BankTransaction = undefined;
  accountDetails: BankAccountDetails;
  currentAmount: number = 0;
  currentBalance: number = 0;
  currentTransactionType: number = -1;
  currentTransactionAsmachta: string = "";
  currentTransactionDateS: string = "";
  transactionTypeNames: string[] = [];
  lastActionFail: boolean = false;
  currentDiv: number = 0;
  userLoginOk: boolean = false;
  typedUserCredentils: UserCredentials = new UserCredentials();
  defaultUserCredentils: UserCredentials = new UserCredentials("ploni", this.encrptPwd("123456"));
  crntPwd: string = "";
  nwPwd: string = "";
  renwPwd: string = "";
  displayTransactionsTable: boolean = false;
  transactions: BankTransaction[] = [];
  lastBalanceBeforeDeletion: number = 0;
  constructor() {
    //this.transaction=new BankTransaction(1000,undefined,"opening",TransactionType.openAccount);
    this.accountDetails = new BankAccountDetails("plonit almonit", "ta", "female", 129387465);
    for (let typename in TransactionType)
      if (isNaN(Number(typename)))
        this.transactionTypeNames.push(typename);

    this.loadInitUserCredentialsData();
    this.getTransArrayFromLocalStorage();
  }
  changePwd() {
    let noproblem: boolean =false;

    if (this.encrptPwd(this.crntPwd.trim())!=this.defaultUserCredentils.pwd)
    {
      alert ("הסיסמא הנוכחית אשר הזנת הינה שגויה");
      return;
    }
    if (this.nwPwd.trim()!=this.renwPwd.trim())
    {
      alert (" הסיסמא החדשה אשר הזנת אינה תואמת לסיסמא אשר הזנת בשנית  ");
      return;
    }
    if (this.encrptPwd(this.nwPwd.trim())==this.defaultUserCredentils.pwd)
    {
      alert (" על הסיסמא המבוקשת להיות שונה מהסיסמא הנוכחית");
      return;
    }
    if(this.nwPwd.trim().length<6)
    {
      alert ("הסיסמא אשר הזנת קצרה מדי, על הסיסמא להיות לפחות 6 תווים ");
      return;
    }
    noproblem=true;
    if (noproblem) {
      this.defaultUserCredentils.pwd = this.encrptPwd(this.nwPwd.trim());
      this.saveUserCredentials();
      alert("החלפת הסיסמא הצליחה");
      this.logOff();
    }
  }
  encrptPwd(pwd?: string): string {
    return CryptoJS.SHA3(pwd + SALT, { outputLength: 512 }).toString();
  }
  saveUserCredentials() {
    localStorage.setItem(USER_CREDENTIALS_KY, JSON.stringify(this.defaultUserCredentils));
  }
  cngPwd() {
    this.currentDiv = 2;
  }
  loadInitUserCredentialsData() {
    let rdFromLocalstrg = localStorage.getItem(USER_CREDENTIALS_KY);
    if (rdFromLocalstrg == null)
      this.saveUserCredentials();
    else {
      try {
        this.defaultUserCredentils = JSON.parse(rdFromLocalstrg);
      }
      catch
      {
        this.saveUserCredentials();
      }
    }
  }
  toString = (): string => {
    let ezer: string = `${this.transaction} into ${this.accountDetails}`;
    return ezer;
  }
  //toString():string{
  //  return this.title;
  // }
  logIn() {
    console.log(`befor eml:${this.typedUserCredentils.eml}`);
    console.log(`stored eml:${this.defaultUserCredentils.eml}`);
    console.log(`befor enc:${this.encrptPwd(this.typedUserCredentils.pwd?.trim())}`);
    console.log(`stored enc:${this.defaultUserCredentils.pwd}`);
    if (this.typedUserCredentils.eml == this.defaultUserCredentils.eml &&
      this.encrptPwd(this.typedUserCredentils.pwd) == this.defaultUserCredentils.pwd) {

      console.log(`after enc:${this.encrptPwd(this.typedUserCredentils.pwd)}`);
      //this.userLoginOk = true;
      this.currentDiv = 1;
    }
    else
      alert(" שם המשתמש או הסיסמא או הצירוף שגוי")
  }
  logOff() {
    this.currentDiv = 0;
  }
  clrUsrLoginFlds(){
    this.typedUserCredentils.eml = "";
    this.typedUserCredentils.pwd = "";
  }
  saveAsUser() {
    if (!this.typedUserCredentils || !this.typedUserCredentils.eml) {
        alert("קלט לא חוקי. אנא הזן שם משתמש חוקי.");
        return;
    }

    const trimmedEmail = this.typedUserCredentils.eml.trim();
    if (trimmedEmail.length <= 6) {
        alert("על שם המשתמש להיות באורך 6 תווים לפחות");
        return;
    }

    if (trimmedEmail === this.defaultUserCredentils.eml) {
        this.logIn();
    } else {
        this.defaultUserCredentils.eml = trimmedEmail;
        this.saveUserCredentials(); 
        alert("יצירת המשתמש הצליחה");
        this.logIn();
    }
}


  doTransaction(): void {
        if (!(this.currentTransactionType >= 0 && this.currentTransactionType <= 2)){
        alert("סוג הפעולה אשר נבחרה אינו תקין, אנא בחר בשנית");
        return;
        }

      if (this.currentAmount <= 0){
        alert("על סכום הפעולה להיות חיובי וגדול מאפס");
        return;
      }

      if (new Date(this.currentTransactionDateS) > new Date()){
        alert("תאריך הפעולה אינו יכול להיות עתידי");
        return;
      }

      if (this.transactions.length > 0) {
        const lastTransactionDate = this.transactions[this.transactions.length - 1].trnDate;
        if (new Date(this.currentTransactionDateS) < lastTransactionDate) {
            alert("תאריך הפעולה נדרש להיות גדול או שווה לתאריך האחרון ברשימת הפעולות.");
            return;
        }
      }
        
      
  

    switch (this.currentTransactionType * 1) {
      case TransactionType.deposit:
        this.currentBalance += this.currentAmount;
        break;
      case TransactionType.withdraw:
        if (this.currentBalance - this.currentAmount < this.accountDetails.limit) {
          this.lastActionFail = true;
          return;
        }
        else
          this.currentBalance -= this.currentAmount;
        break;
      case TransactionType.openAccount:
        this.currentBalance = 0;
        this.transactions = [];
        break;
      default:
        alert("לא בחרת סוג פעולה");
        return;

    }


    const newTransaction = new BankTransaction(
      this.currentAmount,
      new Date(this.currentTransactionDateS),
      this.currentTransactionAsmachta,
      this.currentTransactionType,
      this.currentBalance
    );
   
    this.transactions.push(newTransaction);
    this.lastActionFail = false;

    this.SaveTransArrayInLocalStorage();
  

    /*let tranType: TransactionType;
    if (this.currentAmount > 0)
      tranType = TransactionType.deposit;
    else if (this.currentAmount < 0)
      tranType = TransactionType.withdraw;
    else
      tranType = TransactionType.openAccount;

    this.transaction = new BankTransaction(this.currentAmount, new Date(), "", tranType);

    if (tranType == TransactionType.openAccount)
      this.currentBalance = 0;
    else
      this.currentBalance += this.currentAmount;
*/
  }


  encryptString(str: string): string {
    return CryptoJS.AES.encrypt(str, SALT).toString();
  }

  decryptData(str: string): string { //המערך המפוענח
    return CryptoJS.AES.decrypt(str, SALT).toString(CryptoJS.enc.Utf8);
  }
  

  SaveTransArrayInLocalStorage(): void {
    try {
      const encryptedTransactions = this.encryptString(JSON.stringify(this.transactions));
      localStorage.setItem(TRANSACTIONS_STORAGE_KEY, encryptedTransactions);
    } catch (error) {
      console.error("שגיאה בשמירת נתוני המערך:", error);
    }
  }


  getTransArrayFromLocalStorage(): void {
    const encryptedData = localStorage.getItem(TRANSACTIONS_STORAGE_KEY);
    if (encryptedData) {
      try {
        const decryptedData = this.decryptData(encryptedData);
        this.transactions = JSON.parse(decryptedData);
      } catch (error) {
        console.error("שגיאה בפענוח נתוני המערך:", error);
      }
    }
  } 


  deleteTransaction(index: number): void{
    this.lastBalanceBeforeDeletion = this.currentBalance;
    this.transactions.splice(index, 1);
    this.SaveTransArrayInLocalStorage();

    this.calculateTotalBalance();
    
  }

  calculateTotalBalance(): void {
    this.currentBalance = 0;

    for (const transaction of this.transactions) {
      this.currentBalance += transaction.amount;
    }
  }
}





