
export class UserCredentials {
    constructor(public eml?:string,public pwd?:string){}
}